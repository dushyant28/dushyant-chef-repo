default['ip_pfmd']['arch'] = '32-bit'   # The other vaule can be 64-bit

# S3 bucket where installers are kept 
default['ip_pfmd']['bucket_name'] = 'chef-packages-geip-us-standard'

# Installation Directory
# default['ip_pfmd']['install_dir'] = ''
